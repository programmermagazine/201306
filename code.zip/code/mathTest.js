var m=require("./math");

console.log("PI=%d square(3)=%d", m.PI, m.square(3));
