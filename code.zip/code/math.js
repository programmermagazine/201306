var math = {
    PI:3.14,
    square:function(n) {
        return n*n;
    }
}

module.exports = math;
